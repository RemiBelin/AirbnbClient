import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-photos',
  templateUrl: './dialog-photos.component.html',
  styleUrls: ['./dialog-photos.component.css']
})
export class DialogPhotosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
